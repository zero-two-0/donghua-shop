package com.sky.service;

import com.sky.vo.BusinessDataVO;
import com.sky.vo.TurnoverReportVO;
import java.time.LocalDate;

public interface ReportService {
    TurnoverReportVO turnoverStatistics(LocalDate begin, LocalDate end);
    BusinessDataVO businessData(LocalDate date);
}
